/*
 * Timer.c
 *
 * Created: 2018/09/07 9:25:02 AM
 *  Author: FJ-PC
 */

#include "Timer.h" 


void Timer1_Frequency(uint8_t freq)
{
	TCCR1B |= (1<<CS12) | (1<<CS10) | (1<<WGM12);
	TIMSK1 |= (1<<OCIE1A);
	
	OCR1A = (F_CPU/(freq*2*1024)-1);
	
}

void millis_timer0_10()
{
	TCCR0A |= (1<<WGM01);
	TCCR0B |= (1<<CS02) | (1<<CS00);
	
	OCR0A = 77;
	
	TIMSK0 |= (1<<OCIE0A);
	
}

void Stop_timer0_10()
{
	TCCR0B &= ~(1<<CS02);
	TCCR0B &= ~(1<<CS00);
	TIMSK0 &= ~(1<<OCIE0A);
	
}

void Stop_timer1_Frequency()
{
	TCCR1B &= ~(1<<CS12);
	TCCR1B &= ~(1<<CS10);
	TIMSK1 &= ~(1<<OCIE1A);
	
}