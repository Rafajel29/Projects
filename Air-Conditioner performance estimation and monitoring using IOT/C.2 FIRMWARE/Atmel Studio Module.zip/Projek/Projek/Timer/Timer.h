/*
 * Timer.h
 *
 * Created: 2018/09/07 9:24:52 AM
 *  Author: FJ-PC
 */ 


#ifndef TIMER_H_
#define TIMER_H_

#include <avr/io.h>
#include <stdio.h>

#define F_CPU 16000000UL

void Timer1_Frequency(uint8_t freq);
void millis_timer0_10();
void Stop_timer0_10();
void Stop_timer1_Frequency();





#endif /* TIMER_H_ */