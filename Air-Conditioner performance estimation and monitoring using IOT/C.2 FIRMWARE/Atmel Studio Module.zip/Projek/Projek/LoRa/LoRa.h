/*
 * LoRa.h
 *
 * Created: 2018/08/27 9:10:10 PM
 *  Author: FJ-PC
 */ 






#ifndef LORA_H_
#define LORA_H_

#include <stdint.h>

typedef unsigned char                   UINT8;
typedef uint16_t                        UINT16;
typedef uint32_t                        UINT32;

#define WIMOD_HCI_MSG_HEADER_SIZE       2
#define WIMOD_HCI_MSG_PAYLOAD_SIZE      300
#define WIMOD_HCI_MSG_FCS_SIZE          2

#define LOBYTE(x)                       (x)
#define HIBYTE(x)                       ((UINT16)(x) >> 8)

typedef struct
{
	// Payload Length Information,
	// this field not transmitted over UART interface !!!
	UINT16  Length;

	// Service Access Point Identifier
	UINT8   SapID;

	// Message Identifier
	UINT8   MsgID;

	// Payload Field
	UINT8   Payload[WIMOD_HCI_MSG_PAYLOAD_SIZE];

	// Frame Check Sequence Field
	UINT8   CRC16[WIMOD_HCI_MSG_FCS_SIZE];

}TWiMOD_HCI_Message;


//------------------------------------------------------------------------------
//
//  Endpoint (SAP) Identifier
//
//------------------------------------------------------------------------------

#define DEVMGMT_SAP_ID                      0x01
#define LORAWAN_SAP_ID                      0x10

//------------------------------------------------------------------------------
//
//  Device Management SAP Message Identifier
//
//------------------------------------------------------------------------------

// Status Identifier
#define	DEVMGMT_STATUS_OK                       0x00
#define	DEVMGMT_STATUS_ERROR                    0x01
#define	DEVMGMT_STATUS_CMD_NOT_SUPPORTED        0x02
#define	DEVMGMT_STATUS_WRONG_PARAMETER          0x03
#define DEVMGMT_STATUS_WRONG_DEVICE_MODE        0x04

// Message Identifier
#define DEVMGMT_MSG_PING_REQ                    0x01
#define DEVMGMT_MSG_PING_RSP                    0x02

#define DEVMGMT_MSG_GET_DEVICE_INFO_REQ         0x03
#define DEVMGMT_MSG_GET_DEVICE_INFO_RSP         0x04

#define DEVMGMT_MSG_GET_FW_VERSION_REQ          0x05
#define DEVMGMT_MSG_GET_FW_VERSION_RSP          0x06

#define DEVMGMT_MSG_GET_OP_MODE_REQ             0x0B
#define DEVMGMT_MSG_GET_OP_MODE_RSP             0x0C



//------------------------------------------------------------------------------
//
//  LoRaWAN SAP Message Identifier
//
//------------------------------------------------------------------------------

// Status Identifier
#define LORAWAN_STATUS_OK                       0x00
#define	LORAWAN_STATUS_ERROR                    0x01
#define	LORAWAN_STATUS_CMD_NOT_SUPPORTED        0x02
#define	LORAWAN_STATUS_WRONG_PARAMETER          0x03
#define LORAWAN_STATUS_WRONG_DEVICE_MODE        0x04
#define LORAWAN_STATUS_NOT_ACTIVATED            0x05
#define LORAWAN_STATUS_BUSY                     0x06
#define LORAWAN_STATUS_QUEUE_FULL               0x07
#define LORAWAN_STATUS_LENGTH_ERROR             0x08
#define LORAWAN_STATUS_NO_FACTORY_SETTINGS      0x09
#define LORAWAN_STATUS_CHANNEL_BLOCKED_BY_DC    0x0A
#define LORAWAN_STATUS_CHANNEL_NOT_AVAILABLE    0x0B

// Message Identifier
#define LORAWAN_MSG_JOIN_NETWORK_REQ            0x09
#define LORAWAN_MSG_JOIN_NETWORK_RSP            0x0A
#define LORAWAN_MSG_JOIN_TRANSMIT_IND           0x0B
#define LORAWAN_MSG_JOIN_NETWORK_IND            0x0C

#define LORAWAN_MSG_SEND_UDATA_REQ              0x0D
#define LORAWAN_MSG_SEND_UDATA_RSP              0x0E
#define LORAWAN_MSG_SEND_UDATA_IND              0x0F
#define LORAWAN_MSG_RECV_UDATA_IND              0x10

#define LORAWAN_MSG_SEND_CDATA_REQ              0x11
#define LORAWAN_MSG_SEND_CDATA_RSP              0x12
#define LORAWAN_MSG_SEND_CDATA_IND              0x13
#define LORAWAN_MSG_RECV_CDATA_IND              0x14

#define LORAWAN_MSG_RECV_ACK_IND                0x15
#define LORAWAN_MSG_RECV_NODATA_IND             0x16

#define LoRaWAN_MSG_GET_NWKSTATUS_REQ           0x29
#define LoRaWAN_MSG_GET_NWKSTATUS_RSP           0x2A

#define LoRaWAN_MSG_GET_DEVICEEUI_REQ           0x27
#define LoRaWAN_MSG_GET_DEVICEEUI_RSP           0x28

#define LoRaWAN_MSG_SET_JOINPARAM_REQ           0x05
#define LoRaWAN_MSG_SET_JOINPARAM_RSP           0x06

#define LoRaWAN_MSG_GET_RADIOSTACKCONFIG_REQ    0x1B
#define LoRaWAN_MSG_GET_RADIOSTACKCONFIG_RSP    0x1C

#define LoRaWAN_MSG_GET_LINKADRCONFIG_REQ       0x3D
#define LoRaWAN_MSG_GET_LINKADRCONFIG_RSP       0x3E

#define LoRaWAN_MSG_GET_TXPOWERLIMCONFIG_REQ    0x39
#define LoRaWAN_MSG_GET_TXPOWERLIMCONFIG_RSP    0x3A

#define LoRaWAN_MSG_GET_SUPPORTEDBANDS_REQ      0x35
#define LoRaWAN_MSG_GET_SUPPORTEDBANDS_RSP      0x36

int
WiMOD_LoRaWAN_SendPing();

int
WiMOD_LoRaWAN_GetNwkStatus();

int
WiMOD_LoRaWAN_GetDeviceEUI();

int
WiMOD_LoRaWAN_SetJoinParam(UINT8*  APPEUIdef, UINT8* AppKeydef);

int
WiMOD_LoRaWAN_GetRadioStackConfig();

int
WiMOD_LoRaWAN_GetLinkAdrConfig();

int
WiMOD_LoRaWAN_GetTXPowerLimConfig();

int
WiMOD_LoRaWAN_GetSupportedBands();

int
WiMOD_LoRaWAN_JoinNetwork();

int
WiMOD_DEVMGMT_GetOpMode();

int
WiMOD_DEVMGMT_GetFwVersion();

int
WiMOD_DEVMGMT_GetDeviceInfo();

int
WiMOD_HCI_SendMessage(TWiMOD_HCI_Message* txMessage);

int
WiMOD_HCI_Activate();

int
WiMOD_LoRaWAN_SendURadioData(UINT8  port, UINT8* srcData, int    srcLength);

int
WiMOD_LoRaWAN_SendCRadioData(UINT8 port, UINT8* data, int length);


#endif /* LORA_H_ */