/*
 * LoRa.c
 *
 * Created: 2018/08/27 9:09:58 PM
 *  Author: FJ-PC
 */ 

#define F_CPU 16000000UL

#include "LoRa.h"
#include "CRC16.h"
#include "SLIP.h"

#include <string.h>
#include <stdio.h>
//#include <util/delay.h>

#define MAKEWORD(lo,hi) ((lo)|((hi) << 8))
#define MAKELONG(lo,hi) ((lo)|((hi) << 16))

TWiMOD_HCI_Message TxMessage;
static UINT8                TxBuffer[sizeof( TWiMOD_HCI_Message ) * 2 + 2];


int
WiMOD_LoRaWAN_SendPing()
{
	// 1. init header
	TxMessage.SapID     = DEVMGMT_SAP_ID;
	TxMessage.MsgID     = DEVMGMT_MSG_PING_REQ;
	TxMessage.Length    = 0;

	// 2. send HCI message without payload
	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_LoRaWAN_GetNwkStatus()
{
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LoRaWAN_MSG_GET_NWKSTATUS_REQ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_LoRaWAN_GetDeviceEUI()
{
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LoRaWAN_MSG_GET_DEVICEEUI_REQ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_HCI_SendMessage(TWiMOD_HCI_Message* txMessage)
{
	
	if (!txMessage)
	{
		// error
		return -1;
	}

	// 2. Calculate CRC16 over header and optional payload
	//
	UINT16 crc16 = CRC16_Calc(&txMessage->SapID,
	txMessage->Length + WIMOD_HCI_MSG_HEADER_SIZE,
	CRC16_INIT_VALUE);

	// 2.1 get 1's complement !!!
	
	crc16 = ~crc16;

	// 2.2 attach CRC16 and correct length, LSB first
	//
	txMessage->Payload[txMessage->Length]     = LOBYTE(crc16);
	txMessage->Payload[txMessage->Length + 1] = HIBYTE(crc16);

	// 3. perform SLIP encoding
	//    - start transmission with SAP ID
	//    - correct length by header size

	int txLength = SLIP_EncodeData(TxBuffer, sizeof(TxBuffer), &txMessage->SapID, txMessage->Length + WIMOD_HCI_MSG_HEADER_SIZE + WIMOD_HCI_MSG_FCS_SIZE);
	// message ok ?
	if (txLength > 0)
	{
		// send wakeup chars
		for(int i= 0; i < 40; i++)
		{
			USART0_Transmit(SLIP_END);
		}
		

		char message[6];
		message[1] = SLIP_END;
		message[2] = txMessage->SapID;
		message[3] = txMessage->MsgID;
		message[4] = LOBYTE(crc16);
		message[5] = HIBYTE(crc16);		
		message[6] = SLIP_END;
		
		char messagepay[300];
		int Len = txMessage->Length;
		int i = Len;
		int j = 0;
		
		USART0_Transmit(message[1]);
		USART0_Transmit(message[2]);
		USART0_Transmit(message[3]);
		
		for (j = 0; j<Len; j++)
		{
			USART0_Transmit(txMessage->Payload[j]);
		}
		
		while (txMessage->Payload[i] != 0x00)
		{
			USART0_Transmit(txMessage->Payload[i]);
			i++;
		}
		//USART0_Transmit(message[4]);
		//USART0_Transmit(message[5]);
		USART0_Transmit(message[6]);
		
		
		return 1;		
	}

	// error - SLIP layer couldn't encode message - buffer to small ?
	return -1;
}

int
WiMOD_LoRaWAN_Activate()
{
	for(int i= 0; i < 40; i++)
	{
		USART0_Transmit(SLIP_END);
	}
	
	char message[] = {0xC0, 0x10, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0xF8, 0x43, 0xC0};
	for(int i= 0; i < 42; i++)
	{
		USART0_Transmit(message[i]);
	}
	
	return 0;
}

int
WiMOD_LoRaWAN_SendURadioData(UINT8  port,UINT8* srcData, int    srcLength)  // length of application payload
{
	for (int i = 0; i<300; i++)
	{
		TxMessage.Payload[i] = 0x00;
	}
		
	// 1. check length
	if (srcLength > (WIMOD_HCI_MSG_PAYLOAD_SIZE - 1))
	{
		// error
		return -1;
	}

	// 2. init header
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LORAWAN_MSG_SEND_UDATA_REQ;
	TxMessage.Length    = 1 + srcLength;

	// 3.  init payload
	// 3.1 init port
	TxMessage.Payload[0] = port;

	// 3.2 init radio message payload
	memcpy(&TxMessage.Payload[1], srcData, srcLength);

	// 4. send HCI message with payload
	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_LoRaWAN_SendCRadioData(UINT8  port, UINT8* srcData, int    srcLength)  // length of application data
{
	
	for (int i = 0; i<300; i++)
	{
		TxMessage.Payload[i] = 0x00;
	}
		
	// 1. check length
	if (srcLength > (WIMOD_HCI_MSG_PAYLOAD_SIZE - 1))
	{
		// error
		return -1;
	}

	// 2. init header
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LORAWAN_MSG_SEND_CDATA_REQ;
	TxMessage.Length    = 1 + srcLength;

	// 3.  init payload
	// 3.1 init port
	TxMessage.Payload[0] = port;

	// 3.2 init radio message payload
	memcpy(&TxMessage.Payload[1], srcData, srcLength);

	// 4. send HCI message with payload
	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_LoRaWAN_GetRadioStackConfig()
{
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LoRaWAN_MSG_GET_RADIOSTACKCONFIG_REQ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_LoRaWAN_GetLinkAdrConfig()
{
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LoRaWAN_MSG_GET_LINKADRCONFIG_REQ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_LoRaWAN_GetTXPowerLimConfig()
{
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LoRaWAN_MSG_GET_TXPOWERLIMCONFIG_REQ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_LoRaWAN_GetSupportedBands()
{
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LoRaWAN_MSG_GET_SUPPORTEDBANDS_REQ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_LoRaWAN_JoinNetwork()
{
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LORAWAN_MSG_JOIN_NETWORK_REQ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_DEVMGMT_GetOpMode()
{
	TxMessage.SapID     = DEVMGMT_SAP_ID;
	TxMessage.MsgID     = DEVMGMT_MSG_GET_OP_MODE_REQ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_DEVMGMT_GetFwVersion()
{
	TxMessage.SapID     = DEVMGMT_SAP_ID;
	TxMessage.MsgID     = DEVMGMT_MSG_GET_FW_VERSION_REQ ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_DEVMGMT_GetDeviceInfo()
{
	TxMessage.SapID     = DEVMGMT_SAP_ID;
	TxMessage.MsgID     = DEVMGMT_MSG_GET_DEVICE_INFO_REQ;
	TxMessage.Length    = 0;

	return WiMOD_HCI_SendMessage(&TxMessage);
}

int
WiMOD_LoRaWAN_SetJoinParam(UINT8*  APPEUIdef, UINT8* AppKeydef)  // length of application payload
{
	
	for (int i = 0; i<300; i++)
	{
		TxMessage.Payload[i] = 0x00;
	}
	
	TxMessage.SapID     = LORAWAN_SAP_ID;
	TxMessage.MsgID     = LoRaWAN_MSG_SET_JOINPARAM_REQ;
	TxMessage.Length    = 24;

	memcpy(&TxMessage.Payload[0], APPEUIdef, 8);

	memcpy(&TxMessage.Payload[8], AppKeydef, 16);

	return WiMOD_HCI_SendMessage(&TxMessage);
}