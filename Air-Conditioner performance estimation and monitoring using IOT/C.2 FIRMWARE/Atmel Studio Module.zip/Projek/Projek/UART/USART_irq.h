/*
 * USART_irq.h
 *
 * Created: 2018/08/12 8:55:11 PM
 *  Author: FJ-PC
 */ 


#ifndef USART_IRQ_H_
#define USART_IRQ_H_

//#define UBRR_VAL	51
/* USART Buffer Defines */
#define USART_RX_BUFFER_SIZE 128     /* 2,4,8,16,32,64,128 or 256 bytes */
#define USART_TX_BUFFER_SIZE 128     /* 2,4,8,16,32,64,128 or 256 bytes */
#define USART_RX_BUFFER_MASK (USART_RX_BUFFER_SIZE - 1)
#define USART_TX_BUFFER_MASK (USART_TX_BUFFER_SIZE - 1)

/* Prototypes */
void USART0_Init(unsigned int ubrr_val);
unsigned char USART0_Receive(void);
void USART0_Transmit(unsigned char data);
void USART_putstring(char* StringPtr);
int USART0_Transmit_IO(char data, FILE *stream);





#endif /* USART_IRQ_H_ */