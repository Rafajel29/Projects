
#define F_CPU 16000000UL
#define FOSC 16000000 
#define BAUD 115200
#define MYUBRR FOSC/8/BAUD-1

#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdio.h>
#include <math.h>
#include <util/delay.h>
#include <string.h>
#include <util/atomic.h>

#include "UART/USART_irq.h"
#include "ds18b20/ds18b20.h"
#include "LoRa/LoRa.h"
#include "Timer/Timer.h"


static FILE mystdout = FDEV_SETUP_STREAM(USART0_Transmit_IO, NULL, _FDEV_SETUP_WRITE);

#define LED_ON PORTB |= (1<<PORTB4)
#define LED_OFF PORTB &= ~(1<<PORTB4)
#define LED_TOGGLE PINB |= (1<<PINB4)

#define LOBYTE(x)                       (x)
#define HIBYTE(x)                       ((UINT16)(x) >> 8)

UINT8 APPEUI[8] =  {0xBE, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x21};
UINT8 APPKey[16] = {0x93, 0xE1, 0xC2, 0x36, 0x87, 0x98, 0xE0, 0xBE, 0x0E, 0xF7, 0x1B, 0x32, 0xD6, 0x60, 0x6C, 0xD5};

volatile uint16_t samplesvcc = 0;
volatile uint8_t ADCPort = 0;
volatile int OffsetI = 0;
volatile float FilteredI = 0;
volatile int SampleI = 0;
volatile float sumI = 0;
volatile float I_RATIO = 0;
volatile float Irms = 0;
volatile double t1 = 0;
volatile double t2 = 0;
volatile double t3 = 0;
volatile UINT8 TimerCount = 0;
volatile float HighI = 0;
volatile float LowI = 100;


void CalcIrms(uint16_t adcv);
void PrintTemp(void);
void ADC_init(void);

void CalcIrms(uint16_t adcv)
{
	
    	if (ADCPort == 0)
		{
			OffsetI = adcv;
			
			ADCPort = 1;
			ADMUX |= (1<<MUX0);
		}
		else
		{
			SampleI = adcv;
			
			FilteredI = SampleI - OffsetI;
			
			sumI += (FilteredI * FilteredI);
			samplesvcc++;
			
			volatile float tempIcheck;
			tempIcheck = FilteredI * FilteredI;
			
			if (tempIcheck > HighI)
			{
				HighI = tempIcheck;
			}
			
			if (tempIcheck < LowI)
			{
				LowI = tempIcheck;
			}
			
			ADMUX &= ~(1<<MUX0);
			ADCPort = 0;
			
			if (samplesvcc == 1000)
			{
				
				I_RATIO = 0.28;//0.28; //60 * ((4752/1000)/(1024))
				Irms = I_RATIO * sqrt(sumI/1000);
				LowI = I_RATIO * sqrt(LowI * LowI);
				HighI = I_RATIO * sqrt(HighI * HighI);
				samplesvcc = 0;
				
				sumI = 0;
				ADCPort = 0;
				ADMUX &= ~(1<<MUX0);
				PrintTemp();
				
			}
		}
			
}



void PrintTemp(void)
{
	Stop_timer0_10();////////////////////////////////////
	t1=ds18b20_gettemp(0);
	t2=ds18b20_gettemp(1);
	t3=ds18b20_gettemp(2);
					

	//printf("\r\nCurrent1 = %4.2f",Irms);/////////////////////////////////////
	float Cur1 = Irms * 100;
	uint16_t CurI1 = floorf(Cur1);
	float CurH = HighI * 100;
	uint16_t CurIH = floorf(CurH);
	float CurL = LowI * 100;
	uint16_t CurIL = floorf(CurL);
	
	HighI = 0;
	LowI = 100;
	
	//printf("\r\nTemp1 = %5.2f",t1);////////////////////////
	//printf("\r\nTemp2 = %5.2f",t2);////////////////////////
	float Tem1 = t1 * 100;
	uint16_t TemI1 = floorf(Tem1);
	float Tem2 = t2 * 100;
	uint16_t TemI2 = floorf(Tem2);
	float Tem3 = t3 * 100;
	uint16_t TemI3 = floorf(Tem3);
		
	
	
	UINT8 port = 0x03;

	UINT8 data[12];
	
	data[0] = 0x01;
	data[1] = 0x01;
	data[2] = 0x01;
	data[3] = 0x01;
	data[4] = 0x01;
	data[5] = 0x01;
	data[6] = 0x01;
	data[7] = 0x01;
	data[8] = 0x01;
	data[9] = 0x01;			
	data[10] = 0x01;
	data[11] = 0x01;
		
	data[0] = LOBYTE(CurI1);
	data[1] = HIBYTE(CurI1);
	data[2] = LOBYTE(CurIH);
	data[3] = HIBYTE(CurIH);
	data[4] = LOBYTE(CurIL);
	data[5] = HIBYTE(CurIL);	
				
	data[6] = LOBYTE(TemI1);
	data[7] = HIBYTE(TemI1);
	data[8] = LOBYTE(TemI2);
	data[9] = HIBYTE(TemI2);
	data[10] = LOBYTE(TemI3);
	data[11] = HIBYTE(TemI3);
			
	//WiMOD_LoRaWAN_SendPing();
				
	//WiMOD_LoRaWAN_GetNwkStatus();
	//WiMOD_LoRaWAN_GetDeviceEUI();
	WiMOD_LoRaWAN_SendURadioData(port, data, 12);///////////////////////////////
	
	Timer1_Frequency(1);////////////////////////
	
	HighI = 0;
	LowI = 100;	
	
}

int main(void)
{

	
	DDRB |= (1<<DDB4) | (1<<DDB2);
	LED_ON;
	
	
	ADC_init();
	//millis_timer0_10();//////////////
	Timer1_Frequency(1);	/////////////////
	USART0_Init(MYUBRR);
				
	stdout = &mystdout;
	
			
	_delay_ms(5000);///////////////////////////////////////////
	sei();
	
	WiMOD_LoRaWAN_SetJoinParam(APPEUI, APPKey);////////////////////
	_delay_ms(100);
	WiMOD_LoRaWAN_JoinNetwork();	/////////////////////////////////
	
    while (1) 
    {
           
    }
}

void ADC_init(void)
{
	ADMUX |= (1<<REFS0);
	ADCSRA |= (1<<ADEN) | (1<<ADSC) | (1<<ADATE) | (1 << ADIE) | (1 << ADPS2) | (1<<ADPS1);
	ADCSRB |= (1<<ADTS1) | (1<<ADTS0);
	//ADMUX |= (1<<MUX0);
	ADCPort = 0;
	
}

ISR(TIMER0_COMPA_vect)
{

}

ISR(TIMER1_COMPA_vect)
{
	TimerCount++;
	LED_TOGGLE;
	
	if (TimerCount == 150)//150
	{
		TimerCount = 0;
		LED_ON;
		Stop_timer1_Frequency();
		millis_timer0_10();		
	}
}

ISR(ADC_vect)
{
	uint16_t duty = ADC;
	
	CalcIrms(duty);
}